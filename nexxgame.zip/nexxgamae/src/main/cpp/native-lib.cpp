#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_nexparkour_game_MainActivity_getEngineStatus(
    JNIEnv* env,
    jobject
) {
    return env->NewStringUTF(
        "C++ ENGINE CONNECTED - READY!"
    );
}